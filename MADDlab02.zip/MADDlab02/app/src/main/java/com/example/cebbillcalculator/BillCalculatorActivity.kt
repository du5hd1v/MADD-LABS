package com.example.cebbillcalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class BillCalculatorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bill_calculator)

        val etUnits = findViewById<EditText>(R.id.etUnits)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val inputUnits = etUnits.text.toString().trim()

            if (inputUnits.isNotEmpty()) {
                val units = inputUnits.toDouble()

                // Rates from Lab Sheet
                val fixedCharge = 150.0   // 150 LKR
                val unitCost = 29.0       // 29 LKR per unit
                val vatRate = 0.15        // 15% VAT

                // Calculation logic
                val energyCharge = units * unitCost
                val subTotal = fixedCharge + energyCharge
                val totalBill = subTotal + (subTotal * vatRate)

                // Display result
                tvResult.text = String.format("Electricity Bill: LKR %.2f", totalBill)
            } else {
                Toast.makeText(this, "Please enter units", Toast.LENGTH_SHORT).show()
            }
        }
    }
}