# Implementation Plan - Fix Warnings and Errors in CEB Bill Calculator

The current file `CEB Bill Calculator.kt` has several issues:
1. **Invalid Class Name**: The class name `` `CEB Bill Calculator` `` contains spaces, which is not allowed in Android projects and causes compilation errors.
2. **Unresolved Reference 'R'**: The `R` class is not being resolved, likely due to the compilation error in the class name or a missing import.
3. **Manifest Mismatch**: The `AndroidManifest.xml` expects an activity named `MainActivity`, but the project has `CEB Bill Calculator`.

Additionally, `BillCalculatorActivity.kt` has a similar `R` resolution issue and a warning regarding `String.format` locale.

## User Review Required

> [!IMPORTANT]
> I will rename the class `CEB Bill Calculator` to `MainActivity` to match the `AndroidManifest.xml` and follow standard naming conventions. I will also attempt to rename the file to `MainActivity.kt` using a shell command to ensure project consistency.

## Proposed Changes

### [app]

#### [MODIFY] [CEB Bill Calculator.kt](file:///C:/Users/dushm/AndroidStudioProjects/MADDlab02/app/src/main/java/com/example/cebbillcalculator/CEB%20Bill%20Calculator.kt) (to be renamed to MainActivity.kt)
- Rename class `` `CEB Bill Calculator` `` to `MainActivity`.
- Add explicit import for `com.example.cebbillcalculator.R` to resolve the `R` reference.

#### [MODIFY] [BillCalculatorActivity.kt](file:///C:/Users/dushm/AndroidStudioProjects/MADDlab02/app/src/main/java/com/example/cebbillcalculator/BillCalculatorActivity.kt)
- Add explicit import for `com.example.cebbillcalculator.R`.
- Fix `String.format` warning by using `Locale.getDefault()`.

## Verification Plan

### Automated Tests
- Run `gradlew assembleDebug` to ensure the project builds successfully without errors.

### Manual Verification
- Verify that the `R` references in both activities are resolved in the IDE.
- Confirm that the `MainActivity` (formerly `CEB Bill Calculator`) is correctly recognized as the launcher activity.
