package com.camlink.madd_lab_03

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class AnswerFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_answer, container, false)

        val tvAnswer = view.findViewById<TextView>(R.id.tvAnswer)
        val btnBack = view.findViewById<Button>(R.id.btnBack)

        val result = arguments?.getDouble(ARG_RESULT) ?: 0.0
        tvAnswer.text = "Answer: $result"

        btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        return view
    }

    companion object {
        private const val ARG_RESULT = "arg_result"

        fun newInstance(result: Double): AnswerFragment {
            val fragment = AnswerFragment()
            val args = Bundle().apply {
                putDouble(ARG_RESULT, result)
            }
            fragment.arguments = args
            return fragment
        }
    }
}
