package com.camlink.madd_lab_03

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment

class CalculatorFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_calculator, container, false)

        val etNum1 = view.findViewById<EditText>(R.id.etNum1)
        val etNum2 = view.findViewById<EditText>(R.id.etNum2)

        val btnAdd = view.findViewById<Button>(R.id.btnAdd)
        val btnSubtract = view.findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = view.findViewById<Button>(R.id.btnMultiply)
        val btnDivide = view.findViewById<Button>(R.id.btnDivide)

        fun calculateAndNavigate(operation: (Double, Double) -> Double) {
            val num1Str = etNum1.text.toString()
            val num2Str = etNum2.text.toString()

            if (num1Str.isEmpty() || num2Str.isEmpty()) {
                Toast.makeText(context, "Please enter both numbers", Toast.LENGTH_SHORT).show()
                return
            }

            val num1 = num1Str.toDouble()
            val num2 = num2Str.toDouble()

            val result = operation(num1, num2)

            val answerFragment = AnswerFragment.newInstance(result)
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, answerFragment)
                .addToBackStack(null)
                .commit()
        }

        btnAdd.setOnClickListener { calculateAndNavigate { a, b -> a + b } }
        btnSubtract.setOnClickListener { calculateAndNavigate { a, b -> a - b } }
        btnMultiply.setOnClickListener { calculateAndNavigate { a, b -> a * b } }
        btnDivide.setOnClickListener {
            val num2Str = etNum2.text.toString()
            if (num2Str.isNotEmpty() && num2Str.toDouble() == 0.0) {
                Toast.makeText(context, "Cannot divide by zero", Toast.LENGTH_SHORT).show()
            } else {
                calculateAndNavigate { a, b -> a / b }
            }
        }

        return view
    }
}
